SPSSTEREO_PATH = 'spsstereo';
DATA_DIR = '../data';
DETECTOR_DIR = fullfile(DATA_DIR, 'detectors');